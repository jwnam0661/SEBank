package sungjuk.server;

import java.io.*;
import java.net.*;

import sungjuk.protocol.Command;
import sungjuk.vo.Student;
import sungjuk.vo.Sungjuk;

public class SungjukServer {
	private ServerSocket server;
	private Socket socket;
	
	private final int PORT = 9974;
	
	private Command cmd;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private SungjukServerManager ssm = new SungjukServerManager();
	
	
	public static void main(String[] arg) {	
		SungjukServer ss = new SungjukServer();
		
		try {
			ss.server = new ServerSocket(ss.PORT);
			System.out.println("Server : Ready to Connect");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		while(true){
			try {
				ss.socket = ss.server.accept();
				System.out.println("Server : Connected to " + ss.socket.getInetAddress().getHostAddress());
				new Thread(new SungjukServerThread(ss.socket)).start();		
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
