package sungjuk.server;

import java.sql.*;
import java.util.*;

import sungjuk.manager.*;
import sungjuk.vo.*;

public class SungjukServerManager implements SungjukManager {

	@Override
	public boolean addStudent(Student s) {
		boolean result = false;
		Connection con = null;
		String sql = "INSERT into student values(?, ?, ?)";
		int i = 0;
		
		try {
			con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, s.getName());
			ps.setInt(2, s.getAge());
			ps.setString(3, s.getStdNo());
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			ConnectionManager.close(con);
		}
		System.out.println(i);
		
		if(i == 1){
			result = true;
		} 
		return result;
	}

	@Override
	public void addScore(Sungjuk s) {
		Connection con = null;
		String sql = "INSERT into sungjuk values (no_seq.nextval, ?, ?, ?)";
		
		try {
			con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, s.getSubject());
			ps.setInt(2, s.getScore());
			ps.setString(3, s.getStdNo());
			ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			ConnectionManager.close(con);
		}
	}

	@Override
	public Student searchStudent(String stdNo) {
		Connection con = null;
		String sql = "SELECT * from student where STDNO = ?";
		Student ss = null;
		
		try {
			con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, stdNo);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				String name = rs.getString("name");
				int age =rs.getInt("age");
				String stdno = rs.getString("stdno");
				ss = new Student(name, age, stdno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.close(con);
		}
		return ss;
	}

	@Override
	public ArrayList<Sungjuk> getAllSungjuk(String stdNo) {
		ArrayList<Sungjuk> sal = new ArrayList<Sungjuk>();
		Connection con = null;
		String sql = "SELECT * from sungjuk WHERE stdno= ? ORDER by no";
		
		try {
			con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, stdNo);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				String subject = rs.getString("subject");
				int score = rs.getInt("score");
				String stdno = rs.getString("stdno");
				sal.add(new Sungjuk(subject, score, stdno));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.close(con);
		}
		return sal;
	}

	@Override
	public void deleteStudent(String stdNo) {
		Connection con = null;
		String sql = "DELETE student WHERE stdno = ?";
		String sql2 = "DELETE sungjuk WHERE stdno = ?";
		
		try {
			con = ConnectionManager.getConnection();
			con.setAutoCommit(false);
			PreparedStatement ps = con.prepareStatement(sql2);
			ps.setString(1, stdNo);
			ps.executeUpdate();
			con.commit();
			ps = con.prepareStatement(sql);
			ps.setString(1, stdNo);
			ps.executeUpdate();
			con.commit();
			con.setAutoCommit(true);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.close(con);
		}

	}

	@Override
	public ArrayList<Student> getAllStudents() {
		ArrayList<Student> sal = new ArrayList<Student>();
		Connection con = null;
		String sql = "SELECT * from student ORDER by stdno";
		
		try {
			con = ConnectionManager.getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			String name, stdNo = null; int age = 0;
			while(rs.next()){
				name = rs.getString("name");
				age = rs.getInt("age");
				stdNo = rs.getString("stdno");
				sal.add(new Student(name, age, stdNo));
			}
			for(Student s : sal){
				s.setSungjukList(getAllSungjuk(stdNo));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionManager.close(con);
		}
	
		return sal;
	}

}
