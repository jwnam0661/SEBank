package sungjuk.server;

import java.io.*;
import java.net.*;

import sungjuk.protocol.*;
import sungjuk.vo.Student;
import sungjuk.vo.Sungjuk;

public class SungjukServerThread implements Runnable {
	
	private Socket socket;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	private Command cmd;
	private SungjukServerManager ssm = new SungjukServerManager();
	
	public SungjukServerThread(Socket socket) throws IOException{
		this.socket = socket;
		System.out.println("Thread in");
	}
	
	@Override
	public void run() {		
		try {
			System.out.println("Thread Running");
			ois = new ObjectInputStream(socket.getInputStream());
			System.out.println(ois);
			oos = new ObjectOutputStream(socket.getOutputStream());
			System.out.println(oos);	
			
			while(socket.isConnected()){
				System.out.println("While - Socket is Connected");
				cmd = (Command) ois.readObject();
				Object[] args = cmd.getArgs();
								
				switch(cmd.getCommandValue()){
					case Command.ADD_STUDENT:
						cmd.setResult(ssm.addStudent((Student) args[0]));
						oos.writeObject(cmd);
						System.out.println("Add Student");
						break;
					case Command.ADD_SCORE:
						ssm.addScore((Sungjuk) args[0]);
						cmd.setResult(null);
						oos.writeObject(cmd);
						System.out.println("Add Score");
						break;
					case Command.SEARCH_STUDENT:
						cmd.setResult(ssm.searchStudent((String) args[0]));
						oos.writeObject(cmd);
						System.out.println("Search Student");
						break;
					case Command.GET_ALL_SUNGJUK:
						System.out.println(ssm.getAllSungjuk((String) args[0]));
						cmd.setResult(ssm.getAllSungjuk((String) args[0]));
						oos.writeObject(cmd);
						System.out.println("Get All Sungjuk");
						break;
					case Command.DELETE_STUDENT:
						ssm.deleteStudent((String) args[0]);
						cmd.setResult(null);
						oos.writeObject(cmd);
						System.out.println("Student Deleted");
						break;
					case Command.GET_ALL_STUDENTS:
						cmd.setResult(ssm.getAllStudents());
						oos.writeObject(cmd);
						System.out.println("Get All Students");
						break;
				}		
			}
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
