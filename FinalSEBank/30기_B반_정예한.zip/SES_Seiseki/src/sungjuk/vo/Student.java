package sungjuk.vo;

import java.io.Serializable;
import java.util.ArrayList;

public class Student implements Serializable {
	private String name;	//�̸�
	private int age;		//����
	private String stdNo;	//�й�
	private ArrayList<Sungjuk> sungjukList = new ArrayList<>();	//�л��� ���� ���� ���
	
	public Student(String name, int age, String stdNo) {
		this.name = name;
		this.age = age;
		this.stdNo = stdNo;
	}
	
	public Student(String name, int age, String stdNo,
			ArrayList<Sungjuk> sungjukList) {
		this.name = name;
		this.age = age;
		this.stdNo = stdNo;
		this.sungjukList = sungjukList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getStdNo() {
		return stdNo;
	}
	
	public ArrayList<Sungjuk> getSungjukList() {
		return sungjukList;
	}

	public void setSungjukList(ArrayList<Sungjuk> sungjukList) {
		this.sungjukList = sungjukList;
	}

	@Override
	public String toString() {
		return String.format("[�̸�: %s, ����: %s, �й�: %s]", name, age, stdNo);
	}
	
	
}
