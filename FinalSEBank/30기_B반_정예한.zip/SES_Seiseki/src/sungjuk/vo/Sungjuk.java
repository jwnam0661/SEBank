package sungjuk.vo;

import java.io.Serializable;

public class Sungjuk implements Serializable {
	private String subject;	//�����
	private int score;		//����
	private String stdNo;	//����
	
	public Sungjuk(String subject, int score) {
		this.subject = subject;
		this.score = score;
	}
	
	public Sungjuk(String subject, int score, String stdNo) {
		this.subject = subject;
		this.score = score;
		this.stdNo = stdNo;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public String getStdNo() {
		return stdNo;
	}

	public void setStdNo(String stdNo) {
		this.stdNo = stdNo;
	}

	@Override
	public String toString() {
		return String.format("[����: %s, ����: %s]", subject, score);
	}
	
}
