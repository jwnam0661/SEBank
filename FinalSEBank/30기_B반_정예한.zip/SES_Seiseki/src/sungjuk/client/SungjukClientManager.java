package sungjuk.client;

import java.io.*;
import java.net.*;
import java.util.*;

import jdk.nashorn.internal.runtime.events.RecompilationEvent;
import sungjuk.manager.*;
import sungjuk.protocol.*;
import sungjuk.vo.*;

public class SungjukClientManager implements SungjukManager {
	
	private Socket socket;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	
	private Command cmd;
	
	private final String host = "localhost";
	private final int port = 9974;
	
	public SungjukClientManager(){
		
		try {
			socket = new Socket(host, port);
			System.out.println("Client : Connected");		
			oos = new ObjectOutputStream(socket.getOutputStream());
			System.out.println(oos);
			ois = new ObjectInputStream(socket.getInputStream());
			System.out.println(ois);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean addStudent(Student s) {
		boolean result = false;
		cmd = new Command(Command.ADD_STUDENT);
		Object[] args = {s};
		cmd.setArgs(args);
		this.writeCommand(cmd);
		result = (boolean) receiveCommand();
		return result;
	}

	@Override
	public void addScore(Sungjuk s) {
		cmd = new Command(Command.ADD_SCORE);
		Object[] args = {s};
		cmd.setArgs(args);
		this.writeCommand(cmd);
		this.receiveCommand();
	}

	@Override
	public Student searchStudent(String stdNo) {
		cmd = new Command(Command.SEARCH_STUDENT);
		Object[] args = {stdNo};
		cmd.setArgs(args);
		this.writeCommand(cmd);
		Student s = (Student) this.receiveCommand();
		return s;
	}

	@Override
	public ArrayList<Sungjuk> getAllSungjuk(String stdNo) {
		ArrayList<Sungjuk> sal = null;
		cmd = new Command(Command.GET_ALL_SUNGJUK);
		Object[] args = {stdNo};
		cmd.setArgs(args);
		this.writeCommand(cmd);
		sal = (ArrayList<Sungjuk>) receiveCommand();
		return sal;
	}

	@Override
	public void deleteStudent(String stdNo) {
		cmd = new Command(Command.DELETE_STUDENT);
		Object[] args = {stdNo};
		cmd.setArgs(args);
		this.writeCommand(cmd);
		this.receiveCommand();

	}

	@Override
	public ArrayList<Student> getAllStudents() {
		cmd = new Command(Command.GET_ALL_STUDENTS);
		this.writeCommand(cmd);
		ArrayList<Student> sal = (ArrayList<Student>) receiveCommand();
		return sal;
	}
	
	public void writeCommand(Command cmd){
		try {
			oos.writeObject(cmd);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Object receiveCommand(){
		Object recieve = null;
		try {
			cmd = (Command) ois.readObject();
			recieve = cmd.getResult();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return recieve;
	}
	
	public void close(){	
		try {
			ois.close();
			oos.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
