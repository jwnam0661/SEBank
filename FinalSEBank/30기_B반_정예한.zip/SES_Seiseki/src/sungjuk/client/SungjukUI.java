package sungjuk.client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import sungjuk.vo.*;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class SungjukUI implements ActionListener {

	private JFrame frame;
	private JTextField tfInsertSUBJECT;
	private JTextField tfInsertSCORE;
	private JTextField tfInsertSTDNO;
	private JTextField tfInsertNAME;
	private JTextField tfInsertAGE;
	private JScrollPane scroll;
	private JList listStudent;
	private JList listScore;
	private JLabel lblSungjukName;
	private JLabel lblSungjukStdNo;
	private JLabel lblAverage;
	private JButton btnStudentInsert;
	private JButton btnSearchStudent;
	private JButton btnDeleteStudent;
	private JButton btnAllStudent;
	private JButton btnStudentCancel;
	private JButton btnSungjukCancel;
	private JButton btnSungjukInsert;
	
	
	private SungjukClientManager sm = new SungjukClientManager();
//	private SungjukServerManager sm = new SungjukServerManager();
	private Student selected;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SungjukUI window = new SungjukUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SungjukUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("���� ����", Font.PLAIN, 12));
		frame.setBounds(100, 100, 700, 415);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panelN = new JPanel();
		panelN.setFont(new Font("���� ����", Font.PLAIN, 12));
		frame.getContentPane().add(panelN, BorderLayout.NORTH);
		
		JLabel lblSoftEngineerSchool = new JLabel("Soft Engineer School \uC131\uC801\uAD00\uB9AC \uC2DC\uC2A4\uD15C");
		lblSoftEngineerSchool.setFont(new Font("���� ����", Font.BOLD, 16));
		panelN.add(lblSoftEngineerSchool);
		
		JPanel panelS = new JPanel();
		panelS.setFont(new Font("���� ����", Font.PLAIN, 12));
		frame.getContentPane().add(panelS, BorderLayout.SOUTH);
		
		btnSearchStudent = new JButton("\uD559\uC0DD\uAC80\uC0C9");
		btnSearchStudent.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnSearchStudent.addActionListener(this);
		panelS.add(btnSearchStudent);
		
		btnDeleteStudent = new JButton("\uD559\uC0DD\uC0AD\uC81C");
		btnDeleteStudent.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnDeleteStudent.addActionListener(this);
		panelS.add(btnDeleteStudent);
		
		btnAllStudent = new JButton("\uC804\uCCB4\uCD9C\uB825");
		btnAllStudent.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnAllStudent.addActionListener(this);
		panelS.add(btnAllStudent);
		
		JPanel panelC = new JPanel();
		panelC.setFont(new Font("���� ����", Font.PLAIN, 12));
		frame.getContentPane().add(panelC, BorderLayout.CENTER);
		panelC.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panelCL = new JPanel();
		panelCL.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC.add(panelCL);
		panelCL.setLayout(new GridLayout(1, 0, 0, 0));
	
		JPanel panelSList = new JPanel();
		panelSList.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelSList.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "\uD559\uC0DD\uBAA9\uB85D", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelCL.add(panelSList);
		panelSList.setLayout(new BorderLayout(0, 0));
		
		
		listStudent = new JList();
		listStudent.setFont(new Font("���� ����", Font.PLAIN, 12));
		listStudent.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				selected = (Student)listStudent.getSelectedValue();
				System.out.println(selected);
				lblSungjukStdNo.setText(selected.getStdNo());
				lblSungjukName.setText(selected.getName());
				clearInsertStudent();
				clearInsertScore();
				lblAverage.setText("");
				setScoreList(selected.getStdNo());
			}
		});
		panelSList.add(new JScrollPane(listStudent));

		JPanel panelC2 = new JPanel();
		panelC2.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelCL.add(panelC2);
		panelC2.setLayout(new BorderLayout(0, 0));
		
		JPanel panelSungjuk = new JPanel();
		panelSungjuk.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC2.add(panelSungjuk);
		panelSungjuk.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "\uC131\uC801", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelSungjuk.setLayout(new BorderLayout(0, 0));
		
		listScore = new JList();
		listScore.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelSungjuk.add(new JScrollPane(listScore));
		
		JPanel panelSU = new JPanel();
		panelSU.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC2.add(panelSU, BorderLayout.SOUTH);
		panelSU.setLayout(new GridLayout(0, 2, 0, 0));
		
		JLabel lblNewLabel = new JLabel("\uD3C9\uADE0");
		lblNewLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelSU.add(lblNewLabel);
		
		lblAverage = new JLabel("New label");
		lblAverage.setHorizontalTextPosition(SwingConstants.CENTER);
		lblAverage.setHorizontalAlignment(SwingConstants.CENTER);
		lblAverage.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblAverage.setText("           ");
		panelSU.add(lblAverage);
		
		JPanel panelCR = new JPanel();
		panelCR.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC.add(panelCR);
		panelCR.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panelC3 = new JPanel();
		panelC3.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC3.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "\uD559\uC0DD\uC785\uB825", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelCR.add(panelC3);
		panelC3.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("\uD559\uBC88");
		lblNewLabel_4.setFont(new Font("���� ����", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(12, 25, 57, 15);
		panelC3.add(lblNewLabel_4);
		
		tfInsertSTDNO = new JTextField();
		tfInsertSTDNO.setFont(new Font("���� ����", Font.PLAIN, 12));
		tfInsertSTDNO.setBounds(42, 22, 116, 21);
		panelC3.add(tfInsertSTDNO);
		tfInsertSTDNO.setColumns(10);
		
		JLabel label_4 = new JLabel("\uC774\uB984");
		label_4.setFont(new Font("���� ����", Font.PLAIN, 12));
		label_4.setBounds(184, 22, 57, 15);
		panelC3.add(label_4);
		
		tfInsertNAME = new JTextField();
		tfInsertNAME.setFont(new Font("���� ����", Font.PLAIN, 12));
		tfInsertNAME.setColumns(10);
		tfInsertNAME.setBounds(214, 19, 116, 21);
		panelC3.add(tfInsertNAME);
		
		JLabel label_5 = new JLabel("\uB098\uC774");
		label_5.setFont(new Font("���� ����", Font.PLAIN, 12));
		label_5.setBounds(12, 53, 57, 15);
		panelC3.add(label_5);
		
		tfInsertAGE = new JTextField();
		tfInsertAGE.setFont(new Font("���� ����", Font.PLAIN, 12));
		tfInsertAGE.setColumns(10);
		tfInsertAGE.setBounds(42, 50, 116, 21);
		panelC3.add(tfInsertAGE);
		
		btnStudentInsert = new JButton("\uB4F1\uB85D");
		btnStudentInsert.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnStudentInsert.addActionListener(this);
		btnStudentInsert.setBounds(48, 93, 97, 23);
		panelC3.add(btnStudentInsert);
		
		btnStudentCancel = new JButton("\uCDE8\uC18C");
		btnStudentCancel.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnStudentCancel.addActionListener(this);
		btnStudentCancel.setBounds(157, 93, 97, 23);
		panelC3.add(btnStudentCancel);
		
		JPanel panelC4 = new JPanel();
		panelC4.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "\uC131\uC801\uC785\uB825", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelCR.add(panelC4);
		panelC4.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panelC4_1 = new JPanel();
		panelC4_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4.add(panelC4_1);
		panelC4_1.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel panelC4_11 = new JPanel();
		panelC4_11.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4_1.add(panelC4_11);
		GridBagLayout gbl_panelC4_11 = new GridBagLayout();
		gbl_panelC4_11.columnWidths = new int[] {43, 123, 0};
		gbl_panelC4_11.rowHeights = new int[]{42, 0};
		gbl_panelC4_11.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panelC4_11.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panelC4_11.setLayout(gbl_panelC4_11);
				
				JLabel label = new JLabel("\uD559\uBC88");
				label.setFont(new Font("���� ����", Font.PLAIN, 12));
				GridBagConstraints gbc_label = new GridBagConstraints();
				gbc_label.fill = GridBagConstraints.BOTH;
				gbc_label.insets = new Insets(0, 0, 0, 5);
				gbc_label.gridx = 0;
				gbc_label.gridy = 0;
				panelC4_11.add(label, gbc_label);
				label.setHorizontalAlignment(SwingConstants.CENTER);
		
				lblSungjukStdNo = new JLabel("          ");
				lblSungjukStdNo.setBorder(new LineBorder(new Color(0, 0, 0)));
				GridBagConstraints gbc_lblSungjukStdNo = new GridBagConstraints();
				gbc_lblSungjukStdNo.fill = GridBagConstraints.BOTH;
				gbc_lblSungjukStdNo.gridx = 1;
				gbc_lblSungjukStdNo.gridy = 0;
				panelC4_11.add(lblSungjukStdNo, gbc_lblSungjukStdNo);
				lblSungjukStdNo.setBackground(Color.WHITE);
		
		JPanel panelC4_12 = new JPanel();
		panelC4_12.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4_1.add(panelC4_12);
		GridBagLayout gbl_panelC4_12 = new GridBagLayout();
		gbl_panelC4_12.columnWidths = new int[] {43, 123, 0};
		gbl_panelC4_12.rowHeights = new int[]{42, 0};
		gbl_panelC4_12.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panelC4_12.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panelC4_12.setLayout(gbl_panelC4_12);
		
		JLabel label_1 = new JLabel("\uC774\uB984");
		label_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		GridBagConstraints gbc_label_1 = new GridBagConstraints();
		gbc_label_1.fill = GridBagConstraints.BOTH;
		gbc_label_1.insets = new Insets(0, 0, 0, 5);
		gbc_label_1.gridx = 0;
		gbc_label_1.gridy = 0;
		panelC4_12.add(label_1, gbc_label_1);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		
		lblSungjukName = new JLabel("                    ");
		lblSungjukName.setBorder(new LineBorder(new Color(0, 0, 0)));
		GridBagConstraints gbc_lblSungjukName = new GridBagConstraints();
		gbc_lblSungjukName.fill = GridBagConstraints.BOTH;
		gbc_lblSungjukName.gridx = 1;
		gbc_lblSungjukName.gridy = 0;
		panelC4_12.add(lblSungjukName, gbc_lblSungjukName);
		
		JPanel panelC4_2 = new JPanel();
		panelC4_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4.add(panelC4_2);
		panelC4_2.setLayout(new GridLayout(0, 2, 0, 0));
		
		JPanel panelC4_21 = new JPanel();
		panelC4_21.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4_2.add(panelC4_21);
		GridBagLayout gbl_panelC4_21 = new GridBagLayout();
		gbl_panelC4_21.columnWidths = new int[] {43, 123, 0};
		gbl_panelC4_21.rowHeights = new int[] {42, 0};
		gbl_panelC4_21.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panelC4_21.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panelC4_21.setLayout(gbl_panelC4_21);
		
		JLabel label_2 = new JLabel("\uACFC\uBAA9");
		label_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		GridBagConstraints gbc_label_2 = new GridBagConstraints();
		gbc_label_2.fill = GridBagConstraints.BOTH;
		gbc_label_2.insets = new Insets(0, 0, 0, 5);
		gbc_label_2.gridx = 0;
		gbc_label_2.gridy = 0;
		panelC4_21.add(label_2, gbc_label_2);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfInsertSUBJECT = new JTextField();
		GridBagConstraints gbc_tfInsertSUBJECT = new GridBagConstraints();
		gbc_tfInsertSUBJECT.fill = GridBagConstraints.BOTH;
		gbc_tfInsertSUBJECT.gridx = 1;
		gbc_tfInsertSUBJECT.gridy = 0;
		panelC4_21.add(tfInsertSUBJECT, gbc_tfInsertSUBJECT);
		tfInsertSUBJECT.setColumns(10);
		
		JPanel panelC4_22 = new JPanel();
		panelC4_22.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4_2.add(panelC4_22);
		GridBagLayout gbl_panelC4_22 = new GridBagLayout();
		gbl_panelC4_22.columnWidths = new int[] {43, 123, 0};
		gbl_panelC4_22.rowHeights = new int[] {42, 0};
		gbl_panelC4_22.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panelC4_22.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panelC4_22.setLayout(gbl_panelC4_22);
		
		JLabel label_3 = new JLabel("\uC810\uC218");
		label_3.setFont(new Font("���� ����", Font.PLAIN, 12));
		GridBagConstraints gbc_label_3 = new GridBagConstraints();
		gbc_label_3.fill = GridBagConstraints.BOTH;
		gbc_label_3.insets = new Insets(0, 0, 0, 5);
		gbc_label_3.gridx = 0;
		gbc_label_3.gridy = 0;
		panelC4_22.add(label_3, gbc_label_3);
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		
		tfInsertSCORE = new JTextField();
		GridBagConstraints gbc_tfInsertSCORE = new GridBagConstraints();
		gbc_tfInsertSCORE.fill = GridBagConstraints.BOTH;
		gbc_tfInsertSCORE.gridx = 1;
		gbc_tfInsertSCORE.gridy = 0;
		panelC4_22.add(tfInsertSCORE, gbc_tfInsertSCORE);
		tfInsertSCORE.setColumns(10);
		
		JPanel panelC4_3 = new JPanel();
		panelC4_3.setFont(new Font("���� ����", Font.PLAIN, 12));
		panelC4.add(panelC4_3);
		
		btnSungjukInsert = new JButton("\uB4F1\uB85D");
		btnSungjukInsert.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnSungjukInsert.addActionListener(this);
		panelC4_3.add(btnSungjukInsert);
		
		btnSungjukCancel = new JButton("\uCDE8\uC18C");
		btnSungjukCancel.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnSungjukCancel.addActionListener(this); 
		panelC4_3.add(btnSungjukCancel);

		setStudentList(sm.getAllStudents());
	}
	
	//�л� ��ü���â
	public void setStudentList(ArrayList<Student> sal){
		Object[] oob = sal.toArray();
		listStudent.setListData(oob);
	}
	
	//�л� ���� ��ü�������â
	public void setScoreList(String stdNo){
		
		//������ ���� ���, ��� ���� ���� ������ ArithmeticException�� ���Ƿ�, �޼����� �����ϱ� ���ؼ� ����߽��ϴ�.
		try{
			ArrayList<Sungjuk> sal = sm.getAllSungjuk(stdNo);
			Object[] oob = sal.toArray();
			listScore.setListData(oob);
			int a = 0, b = 0, t = 0;
			for(int i = 0; i<sal.size(); i++){
				b = sal.get(i).getScore();
				a += b;
			}
			lblAverage.setText(Double.toString(a/sal.size()));
		}catch(ArithmeticException ae){	
		}
	}
	
	//���μ��� â ����
	public void clearScoreList(){
		Object[] ooo = {};
		listScore.setListData(ooo);
		lblAverage.setText("");
	}
	
	//�л��Է� â ����
	public void clearInsertStudent(){
		tfInsertSTDNO.setText("");
		tfInsertNAME.setText("");
		tfInsertAGE.setText("");
	}
	
	//�����Է� â ����
	public void clearInsertScore(){
		tfInsertSUBJECT.setText("");
		tfInsertSCORE.setText("");
	}
	
	//�����Է� �� ����
	public void clearISLabel(){
		lblSungjukName.setText("");
		lblSungjukStdNo.setText("");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object e = arg0.getSource();
		if(e.equals(btnAllStudent)){
			setStudentList(sm.getAllStudents());
			lblAverage.setText("");
			clearScoreList();
			clearISLabel();
			clearInsertStudent();
			clearInsertScore();
			
		}else if(e.equals(btnSearchStudent)){
			String stdNo = JOptionPane.showInputDialog("�й��� �Է����ּ���.");
			Student s = sm.searchStudent(stdNo);
			if(s!=null){
				Object[] ooo = {s};
				listStudent.setListData(ooo);
				setScoreList(s.getStdNo());
			}else{
				JOptionPane.showMessageDialog(null, "�ٽ� �Է����ּ���.");
			}
			clearISLabel();
			clearInsertStudent();
			clearInsertScore();

		}else if(e.equals(btnDeleteStudent)){
			String stdNo = JOptionPane.showInputDialog("�й��� �Է����ּ���.");
			if(sm.searchStudent(stdNo) != null){
				sm.deleteStudent(stdNo);
				setStudentList(sm.getAllStudents());
				clearScoreList();
				lblAverage.setText("");
				clearISLabel();
			}else{
				JOptionPane.showMessageDialog(null, "����� �Ͻô� �й��� �������� �ʽ��ϴ�.");
			}
			clearISLabel();
			clearInsertStudent();
			clearInsertScore();

		}else if(e.equals(btnStudentInsert)){
			try{
				String stdNo = tfInsertSTDNO.getText();
				int age = Integer.parseInt(tfInsertAGE.getText());
				String name = tfInsertNAME.getText();
				if(!sm.addStudent(new Student(name, age, stdNo))){
					JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �й��Դϴ�.");
				}
				setStudentList(sm.getAllStudents());			
			}catch(NumberFormatException nfeIS){
				JOptionPane.showMessageDialog(null, "���̶����� ���ڸ� �Է����ּ���");
			}
			clearISLabel();
			clearInsertScore();
		
		}else if(e.equals(btnStudentCancel)){
			setStudentList(sm.getAllStudents());
			clearISLabel();
			clearInsertStudent();
			clearInsertScore();
			
		}else if(e.equals(btnSungjukInsert)){
			try{
				String sub = tfInsertSUBJECT.getText();
				int sco = Integer.parseInt(tfInsertSCORE.getText());
				String stdno = lblSungjukStdNo.getText();
				sm.addScore(new Sungjuk(sub, sco, stdno));
				setScoreList(stdno);
				clearInsertScore();
			}catch(NumberFormatException nfeS){
				JOptionPane.showMessageDialog(null, "���������� ���ڸ� �Է����ּ���.");
				clearInsertStudent();
			}
			
		}else if(e.equals(btnSungjukCancel)){
			setScoreList(lblSungjukStdNo.getText());
			clearInsertStudent();
			clearInsertScore();
		}		
	}

}
