CREATE table student(
NAME varchar2(20) not null,
AGE number(3) not null,
STDNO varchar2(30) primary key
);

CREATE table sungjuk(
NO number(3) primary key,
SUBJECT varchar2(30) not null,
SCORE number(3) not null,
STDNO varchar2(30) not null constraint sungjuk_stdno_fk references student
);

create sequence no_seq
increment by 1
start with 1
;